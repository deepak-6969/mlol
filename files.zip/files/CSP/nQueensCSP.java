public class nQueensCSP {
    int n;
    int[][] board;

    public nQueensCSP(int n) {
        this.n = n;
        this.board = new int[n][n];
    }

    private boolean isValid(int[][] board, int row, int col) {
        for(int j=0; j<col; j++) // conflicts in same row
            if(board[row][j] == 1) return false;

        for(int i=row, j=col; i>=0 && j>=0; i--, j--) // upper left diagonal
            if(board[i][j] == 1) return false;

        for(int i=row, j=col; i<n && j>=0; i++, j--) // lower left diagonal
            if(board[i][j] == 1) return false;

        return true;
    }

    private void printSolution() {
        System.out.println("\nSolution of " + n + " Queens problem:");
        for(int i=0; i<n; i++) {
            for(int j=0; j<n; j++) {
                System.out.print(board[i][j] + "  ");
            }
            System.out.println();
        }
    }

    private boolean nQueens(int[][] board, int col) {
        if(col >= n) return true; // all queens placed
        for(int row=0; row<n; row++) {
            if(isValid(board, row, col)) {
                board[row][col] = 1; // place queen
                if(nQueens(board, col+1)) return true; // next column
                board[row][col] = 0; // backtrack
            }
        }
        return false; // backtrack
    }

    public void solve() {
        if(nQueens(board, 0)) printSolution();
        else System.out.println("No solution exist!");
    }

    public static void main(String[] args) {
        nQueensCSP fourQueens = new nQueensCSP(4);
        fourQueens.solve();

        nQueensCSP sixQueens = new nQueensCSP(6);
        sixQueens.solve();

        nQueensCSP eightQueens = new nQueensCSP(8);
        eightQueens.solve();
    }
}