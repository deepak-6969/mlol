public class SudokuCSP {
    int n = 9;
    int[][] grid;

    public SudokuCSP(int[][] initialGrid) {
        if(initialGrid.length != n || initialGrid[0].length != n) System.out.println("Invalid Grid Size!");
        else this.grid = initialGrid;
    }

    private boolean isValid(int row, int col, int num) {
        for(int i=0; i<n; i++) {
            if(grid[row][i] == num || grid[i][col] == num || grid[row - row % 3 + i / 3][col - col % 3 + i % 3] == num) return false;
        }
        return true;
    }

    private void printSolution() {
        System.out.println("\n---Sudoku Solution---\n");
        for(int i=0; i<n; i++) {
            for(int j=0; j<n; j++) {
                System.out.print(grid[i][j] + " ");
                if(j % 3 == 2) System.out.print("  ");
            }
            System.out.println();
            if(i % 3 == 2) System.out.println();
        }
    }

    private boolean sudoku(int row, int col) {
        if(row == n) return true;
        if(grid[row][col] != 0) return sudoku(col == n-1 ? row+1 : row, (col+1) % n);
        for(int num=1; num<=n; num++) {
            if(isValid(row, col, num)) {
                grid[row][col] = num;
                if(sudoku(col == n-1 ? row+1 : row, (col+1) % n)) return true;
                grid[row][col] = 0; // backtrack
            }
        }
        return false;
    }

    public void solve() {
        if(sudoku(0,0)) printSolution();
        else System.out.println("No solution exists!");
    }

    public static void main(String[] args) {
        int[][] initialGrid = {
                {5, 3, 0,   0, 7, 0,   0, 0, 0},
                {6, 0, 0,   1, 9, 5,   0, 0, 0},
                {0, 9, 8,   0, 0, 0,   0, 6, 0},

                {8, 0, 0,   0, 6, 0,   0, 0, 3},
                {4, 0, 0,   8, 0, 3,   0, 0, 1},
                {7, 0, 0,   0, 2, 0,   0, 0, 6},

                {0, 6, 0,   0, 0, 0,   2, 8, 0},
                {0, 0, 0,   4, 1, 9,   0, 0, 5},
                {0, 0, 0,   0, 8, 0,   0, 7, 9}
        };

        SudokuCSP sudoku = new SudokuCSP(initialGrid);
        sudoku.solve();
    }
}