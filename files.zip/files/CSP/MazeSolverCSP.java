import java.util.Stack;

class Point {
    int row, col;

    public Point(int row, int col) {
        this.row = row;
        this.col = col;
    }

    public static Point createPoint(int row, int col) {
        return new Point(row, col);
    }
}

public class MazeSolverCSP {
    int[][] maze;

    public MazeSolverCSP(int[][] maze) {
        this.maze = maze;
    }

    Point[] solveMaze() {
        int rows = maze.length;
        int cols = maze[0].length;
        Stack<Point> path = new Stack<>();
        boolean[][] visited = new boolean[rows][cols];
        if (solveMazeCSP(0, 0, rows - 1, cols - 1, visited, path)) {
            return path.toArray(new Point[0]);
        }
        return null; // No solution found
    }

    void mazeSolution() {
        Point[] path = solveMaze();
        if (path != null) {
            System.out.println("Path found:");
            for (Point point : path) {
                System.out.println("(" + point.row + ", " + point.col + ")");
            }
            return;
        }
        System.out.println("No path found.");
    }

    boolean solveMazeCSP(int row, int col, int endRow, int endCol, boolean[][] visited, Stack<Point> path) {
        int rows = maze.length;
        int cols = maze[0].length;
        if (row == endRow && col == endCol) {
            path.push(Point.createPoint(row, col));
            return true; // Reached the end
        }

        if (row >= 0 && row < rows && col >= 0 && col < cols && maze[row][col] == 1 && !visited[row][col]) {
            visited[row][col] = true;
            path.push(Point.createPoint(row, col));
            int[] rowMoves = {1, -1, 0, 0};
            int[] colMoves = {0, 0, 1, -1};
            for (int i = 0; i < 4; i++) {
                int newRow = row + rowMoves[i];
                int newCol = col + colMoves[i];
                if (solveMazeCSP(newRow, newCol, endRow, endCol, visited, path)) return true;
            }
            visited[row][col] = false; // Backtrack
            path.pop();
        }
        return false;
    }

    public static void main(String[] args) {
        int[][] maze = {
                {1, 0, 1, 1, 1},
                {1, 1, 1, 0, 1},
                {0, 1, 0, 1, 1},
                {1, 0, 1, 1, 0},
                {1, 1, 0, 1, 1}
        };

        MazeSolverCSP a = new MazeSolverCSP(maze);
        a.mazeSolution();
    }
}