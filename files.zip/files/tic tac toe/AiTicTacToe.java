import java.util.*;

public class AiTicTacToe {
    char[][] board;
    char player;
    char aiPlayer;
    char curPlayer;

    public AiTicTacToe(char player) {
        board = new char[3][3];
        this.player = player;
        this.aiPlayer = (player == 'x') ? 'o' : 'x';
        this.curPlayer = player;
        initializeBoard();
    }

    private void initializeBoard() {
        for(int i=0; i<3; i++) {
            for(int j=0; j<3; j++) {
                board[i][j] = '-';
            }
        }
    }

    private void printBoard() {
        for(int i=0; i<3; i++) {
            for(int j=0; j<3; j++) {
                System.out.print(board[i][j] + " ");
            }
            System.out.println();
        }
    }

    private boolean isValidMove(int row, int col) {
        return row >= 0 && row < 3 && col >= 0 && col < 3 && board[row][col] == '-';
    }

    private boolean checkWin(char player) {
        if(board[0][0] == player && board[1][1] == player && board[2][2] == player) return true;
        if(board[0][2] == player && board[1][1] == player && board[2][0] == player) return true;
        for(int i=0; i<3; i++) {
            if(board[i][0] == player && board[i][1] == player && board[i][2] == player) return true;
            if(board[0][i] == player && board[1][i] == player && board[2][i] == player) return true;
        }
        return false;
    }

    private boolean boardFull() {
        for(int i=0; i<3; i++) {
            for(int j=0; j<3; j++) {
                if(board[i][j] == '-') return false;
            }
        }
        return true;
    }

    private int minimax(int depth, boolean isMaxPlayer) {
        char op = (aiPlayer == 'x') ? 'o' : 'x'; // opponent
        if(checkWin(aiPlayer)) return 1;
        else if(checkWin(op)) return -1;
        else if(boardFull()) return 0;

        int bestScore;
        if(isMaxPlayer){
            bestScore = Integer.MIN_VALUE;
            for(int i=0; i<3; i++) {
                for(int j=0; j<3; j++) {
                    if(board[i][j] == '-') {
                        board[i][j] = aiPlayer;
                        int score = minimax(depth + 1, false);
                        board[i][j] = '-';
                        bestScore = Math.max(score, bestScore);
                    }
                }
            }
        } else {
            bestScore = Integer.MAX_VALUE;
            for(int i=0; i<3; i++) {
                for(int j=0; j<3; j++) {
                    if(board[i][j] == '-') {
                        board[i][j] = op;
                        int score = minimax(depth + 1, true);
                        board[i][j] = '-';
                        bestScore = Math.min(score, bestScore);
                    }
                }
            }
        }
        return bestScore;
    }

    private int[] getBestMove() {
        int[] bestMove = new int[2];
        int bestScore = Integer.MIN_VALUE;
        for(int i=0; i<3; i++) {
            for(int j=0; j<3; j++) {
                if(board[i][j] == '-') {
                    board[i][j] = aiPlayer;
                    int score = minimax(0, false);
                    board[i][j] = '-';
                    if(score > bestScore) {
                        bestScore = score;
                        bestMove[0] = i;
                        bestMove[1] = j;
                    }
                }
            }
        }
        return bestMove;
    }

    public void playGame() {
        printBoard();
        boolean gameOver = false;
        Scanner sc = new Scanner(System.in);

        while(!gameOver) {
            if(curPlayer == player) {
                System.out.print("Player " + player + " enter your move (row 1-3, col 1-3) : ");
                int row = sc.nextInt() - 1;
                int col = sc.nextInt() - 1;
                if(isValidMove(row, col)) {
                    board[row][col] = player;
                    printBoard();
                    if(checkWin(player)) {
                        System.out.println("Player " + player + " wins!");
                        gameOver = true;
                    } else if(boardFull()) {
                        System.out.print("It's a draw!");
                        gameOver = true;
                    } else {
                        curPlayer = aiPlayer;
                    }
                } else {
                    System.out.println("Invalid move! Try again.");
                }
            } else {
                System.out.println("AI Player's turn!");
                int[] move = getBestMove();
                board[move[0]][move[1]] = aiPlayer;
                printBoard();
                if(checkWin(aiPlayer)) {
                    System.out.println("AI Player wins!");
                    gameOver = true;
                } else if(boardFull()) {
                    System.out.println("It's a draw!");
                    gameOver = true;
                } else {
                    curPlayer = player;
                }
            }
        }
        System.out.println("Game Over!");
    }
}