import java.util.*;

public class TicTacToe {
    char[][] board;
    char player;

    public TicTacToe(char player) {
        board = new char[3][3];
        this.player = player;
        initializeBoard();
    }

    private void initializeBoard() {
        for(int i=0; i<3; i++) {
            for(int j=0; j<3; j++) {
                board[i][j] = '-';
            }
        }
    }

    private void printBoard() {
        for(int i=0; i<3; i++) {
            for(int j=0; j<3; j++) {
                System.out.print(board[i][j] + " ");
            }
            System.out.println();
        }
    }

    private boolean isValidMove(int row, int col) {
        return row >= 0 && row < 3 && col >= 0 && col < 3 && board[row][col] == '-';
    }

    private boolean checkWin(char player) {
        if(board[0][0] == player && board[1][1] == player && board[2][2] == player) return true;
        if(board[0][2] == player && board[1][1] == player && board[2][0] == player) return true;
        for(int i=0; i<3; i++) {
            if(board[i][0] == player && board[i][1] == player && board[i][2] == player) return true;
            if(board[0][i] == player && board[1][i] == player && board[2][i] == player) return true;
        }
        return false;
    }

    private boolean boardFull() {
        for(int i=0; i<3; i++) {
            for(int j=0; j<3; j++) {
                if(board[i][j] == '-') return false;
            }
        }
        return true;
    }

    public void playGame() {
        printBoard();
        boolean gameOver = false;
        Scanner sc = new Scanner(System.in);

        while(!gameOver) {
            System.out.print("Player " + player + " enter your move (row 1-3, col 1-3) : ");
            int row = sc.nextInt() - 1;
            int col = sc.nextInt() - 1;
            if(isValidMove(row, col)) {
                board[row][col] = player;
                printBoard();
                if(checkWin(player)) {
                    System.out.println("Player " + player + " wins!");
                    gameOver = true;
                } else if(boardFull()) {
                    System.out.println("It's a draw!");
                    gameOver = true;
                } else {
                    player = (player == 'x') ? 'o' : 'x';
                }
            } else {
                System.out.println("Invalid move! Try again.");
            }
        }
        System.out.println("Game Over!");
    }
}