import java.util.*;

public class TicTacToePlayGame {
    public static void main(String[] args) {
        System.out.println("\n---*--- Welcome to Tic-Tac-Toe! ---*---\n");
        Scanner sc = new Scanner(System.in);

        System.out.println("For Two-Player Game, Enter 1.\nFor Playing against AI, Enter 2.\n");
        System.out.print("Enter here : ");
        int n = sc.nextInt();

        System.out.print("\nChoose your character (x, o) : ");
        char player = sc.next().charAt(0);

        System.out.println("\nLet's Start!");

        if(n == 1) {
            TicTacToe game = new TicTacToe(player);
            game.playGame();
        } else if(n == 2) {
            AiTicTacToe game = new AiTicTacToe(player);
            game.playGame();
        }
    }
}