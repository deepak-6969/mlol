% Facts: Indian Music Genres, Sample Artists, and Popular Songs
genre(bollywood).
genre(classical).
genre(folk).
genre(pop).

artist(ar_rahman, bollywood).
artist(lata_mangeshkar, classical).
artist(kailash_kher, folk).
artist(arijit_singh, bollywood).
artist(neha_kakkar, pop).
artist(shreya_ghoshal, bollywood).
artist(ustad_amjad_ali_khan, classical).
artist(gurdas_maan, folk).
artist(sonu_nigam, pop).

% Popular Songs
song(tum_hi_ho, arijit_singh, 2013).
song(kabhi_kabhi_aditi, rashid_ali, 2008).
song(tere_bina, a.r_rahman, 2007).
song(chaiyya_chaiyya, sukhwinder_singh, 1998).
song(maaeri, euphoria, 1998).
song(bumbro, udit_narayan, 2000).
song(dil_se_re, a.r_rahman, 1998).
song(ghar, hareem_farooq, 2020).
song(raataan_lambiyan, jubin_nautiyal, 2021).
song(butter, bts, 2021).

% Relationships between Users and Liked Genres and Songs
likes(aarohi, bollywood).
likes(shreya, classical).
likes(neha, folk).
likes(sakshi, pop).
likes(mihir, classical).
likes(om, bollywood).

% Rule for Suggesting Popular Artists
popular_artist(Artist, Genre) :-
    artist(Artist, Genre),
    likes(_, Genre), % Users who like the genre
    findall(User, (likes(User, Genre), artist(Artist, Genre)), Users),
    length(Users, LikesCount),
    LikesCount >= 2. % Considered popular if liked by at least 2 users

% Rule for Suggesting Popular Songs
popular_song(Song, Year) :-
    song(Song, _, Year),
    findall(User, likes(User, _), Users),
    length(Users, UserCount),
    UserCount >= 3. % Considered popular if liked by at least 3 users

% Recommendation Rule for Indian Music
recommend(User, Recommendation) :-
    likes(User, Genre),
    genre(Genre),
    (popular_artist(Recommendation, Genre) ; artist(Recommendation, Genre)),
    \+ Recommendation = _.

recommend(User, Recommendation) :-
    likes(User, _),
    popular_song(Recommendation, _),
    \+ Recommendation = _.

% Rule for Handling Undefined Liked Genre
recommend(User, 'Explore More') :-
    likes(User, Genre),
    \+ genre(Genre).

% Example Queries:
% ?- recommend(aarohi, Recommendation).