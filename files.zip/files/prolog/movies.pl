movie(avengers, action, 2012, 8).
movie(inception, sci_fi, 2010, 8.8).
movie(shawshank_redemption, drama, 1994, 9.3).
movie(pulp_fiction, crime, 1994, 8.9).
movie(interstellar, sci_fi, 2014, 8.6).
movie(forrest_gump, drama, 1994, 8.8).
movie(black_panther, action, 2018, 7.3).
movie(joker, crime, 2019, 8.5).
movie(avatar, sci_fi, 2009, 7.8).
movie(gladiator, action, 2000, 8.5).
movie(titanic, romance, 1997, 7.8).
movie(the_matrix, sci_fi, 1999, 8.7).
movie(deadpool, action, 2016, 8).
movie(gone_girl, mystery, 2014, 8.1).
movie(fight_club, drama, 1999, 8.8).
movie(inside_out, animation, 2015, 8.1).
movie(the_dark_knight, action, 2008, 9).

likes(john, action).
likes(john, sci_fi).
likes(mary, drama).
likes(alex, drama).
likes(alex, action).
likes(sarah, crime).
likes(sarah, sci_fi).
likes(linda, romance).
likes(linda, drama).
likes(james, action).
likes(james, mystery).
likes(susan, animation).
likes(susan, comedy).
likes(steve, action).
likes(steve, drama).

get_movie_recommendations(X) :-
    likes(X, G),
    movie(M, G, _, R),
    R >= 7.5,
    write("Recommended movies for "),
    write(X),
    write(" : "),
    write(M),
    nl.  