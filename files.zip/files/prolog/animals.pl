has_wings(bird).
has_wings(eagle).
has_feathers(bird).
has_beak(bird).
has_beak(eagle).
has_lungs(bird).
has_lungs(cat).
has_lungs(fish).
has_eyes(bird).
has_eyes(cat).
has_eyes(dog).
has_eyes(fish).
has_teeth(eagle).
has_teeth(cat).
has_teeth(dog).
has_teeth(fish).
has_claws(cat).
has_claws(dog).
has_legs(cat).
has_legs(dog).
has_fur(dog).
has_fur(cat).
has_horns(deer).
has_scales(fish).
has_gills(fish).
has_fins(fish).
has_tail(fish).

mammal(cat).
mammal(dog).
not_mammal(bird).

warm_blooded(dog).
warm_blooded(cat).
cold_blooded(fish).

herbivore(deer).
carnivore(eagle).
carnivore(cat).
carnivore(dog).

is_carnivore(X) :- carnivore(X); (has_teeth(X), has_claws(X)).
is_herbivore(X) :- herbivore(X); has_horns(X).
is_mammal(X) :- mammal(X); (has_eyes(X), has_lungs(X), warm_blooded(X)).
is_not_mammal(X) :- not_mammal(X); cold_blooded(X).
can_breathe(X) :- has_lungs(X).
can_eat(X) :- has_teeth(X).
can_fly(X) :- has_wings(X).
can_swim(X) :- has_fins(X).
can_walk(X) :- has_legs(X).
can_see(X) :- has_eyes(X).
