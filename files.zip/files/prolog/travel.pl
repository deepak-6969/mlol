% Facts about destinations
destination('Goa', 'India', 'Beaches', 'Nightlife').
destination('Jaipur', 'India', 'Culture', 'Historical').
destination('Manali', 'India', 'Snow', 'Adventure').
destination('Rishikesh', 'India', 'Adventure', 'Spiritual').

destination('Paris', 'France', 'Culture', 'Nightlife').
destination('Barcelona', 'Spain', 'Beaches', 'Nightlife').
destination('Berlin', 'Germany', 'Culture', 'Nightlife').
destination('Rome', 'Italy', 'Culture', 'Historical').

destination('Tokyo', 'Japan', 'Culture', 'City Life').
destination('Kyoto', 'Japan', 'Culture', 'Historical').
destination('Hawaii', 'USA', 'Beaches', 'Nature').
destination('New York', 'USA', 'City Life', 'Nightlife').

destination('Cancun', 'Mexico', 'Beaches', 'Nightlife').
destination('Dubai', 'UAE', 'City Life', 'Luxury').
destination('Sydney', 'Australia', 'Beaches', 'Nature').
destination('Cape Town', 'South Africa', 'Nature', 'Adventure').

% Rules for recommendations
recommendation(Destination, Duration, Expenses, Type, Location) :-
    destination(Destination, Country, Features, Location),
    duration_suitability(Duration, Destination),
    expenses_suitability(Expenses, Destination),
    type_suitability(Type, Features),
    nl,
    write('Recommended destination: '), write(Destination), nl,
    write('Country: '), write(Country), nl.

recommendation(_, _, _, _, _) :-
    nl,
    write('Sorry, no destination found that matches your criteria. Please try different preferences.'), nl.

% Rules for duration suitability
duration_suitability('Short', Destination) :-
    destination(Destination, _, _, _),
    member(Destination, ['Goa', 'Paris', 'Rome', 'Sydney', 'Cape Town']).
duration_suitability('Medium', Destination) :-
    destination(Destination, _, _, _),
    member(Destination, ['Jaipur', 'Barcelona', 'Berlin', 'Kyoto', 'Hawaii']).
duration_suitability('Long', Destination) :-
    destination(Destination, _, _, _),
    member(Destination, ['Manali', 'Tokyo', 'New York', 'Cancun', 'Dubai']).

% Rules for expenses suitability
expenses_suitability('Low', Destination) :-
    destination(Destination, _, _, _),
    member(Destination, ['Goa', 'Jaipur', 'Berlin', 'Rome', 'Cape Town']).
expenses_suitability('Moderate', Destination) :-
    destination(Destination, _, _, _),
    member(Destination, ['Barcelona', 'Manali', 'Kyoto', 'Hawaii', 'Sydney']).
expenses_suitability('High', Destination) :-
    destination(Destination, _, _, _),
    member(Destination, ['Paris', 'Tokyo', 'New York', 'Cancun', 'Dubai']).

% Rules for type suitability
type_suitability(Type, Features) :-
    member(Type, Features).

% Interactive travel recommendation
recommend_destination :-
    write('Do you prefer destinations within India? (yes/no): '), read(Choice),
    (Choice = yes ->
        Location = 'India';
        Location = 'Outside India'
    ),
    write('Enter your preferred duration (Short/Medium/Long): '), read(Duration),
    write('Enter your budget range (Low/Moderate/High): '), read(Expenses),
    write('Enter your preferred type (Beaches/Culture/Nightlife/Adventure): '), read(Type),
    recommendation(Destination, Duration, Expenses, Type, Location).

% Example usage:
% recommend_destination.