% Symptoms
symptom(fever).
symptom(cough).
symptom(sore_throat).
symptom(runny_nose).
symptom(headache).
symptom(fatigue).
symptom(vomiting).
symptom(diarrhea).
symptom(body_ache).
symptom(chills).
symptom(loss_of_appetite).
symptom(itchy_eyes).

% Diagnoses
diagnose(cold) :- 
    symptom(fever),
    symptom(cough),
    symptom(runny_nose),
    not(symptom(fatigue)),
    not(symptom(body_ache)).

diagnose(influenza) :- 
    symptom(fever),
    symptom(cough),
    symptom(sore_throat),
    symptom(fatigue),
    not(symptom(body_ache)).

diagnose(stomach_flu) :- 
    symptom(vomiting),
    symptom(diarrhea),
    not(symptom(fever)).

diagnose(headache_migraine) :- 
    symptom(headache),
    symptom(itchy_eyes),
    not(symptom(fever)),
    not(symptom(vomiting)),
    not(symptom(diarrhea)).

diagnose(covid19) :- 
    symptom(fever),
    symptom(cough),
    symptom(loss_of_appetite),
    not(symptom(headache)).

diagnose(allergy) :- 
    symptom(runny_nose),
    symptom(sore_throat),
    symptom(itchy_eyes).

% Unknown diagnosis
diagnose(unknown) :- 
    write('Sorry, I cannot diagnose your condition based on these symptoms. Please consult a healthcare professional.'), nl.

% User interaction
ask_symptom(Symptom) :-
    write('Do you have the symptom '), write(Symptom), write('? (yes/no): '),
    read(Response),
    (Response == yes ; Response == no).

diagnose_user :-
    write('Welcome to the symptom diagnosis system!'), nl,
    write('Please answer the following questions with yes or no:'), nl,
    forall(symptom(S), ask_symptom(S)),
    (diagnose(Diagnosis) ->
        format('Based on your symptoms, you may have ~w. Please consult a healthcare professional for confirmation.', [Diagnosis]), nl
    ; 
        diagnose(unknown)
    ).

% Example usage
% Uncomment the line below to test the interactive diagnosis
% diagnose_user.
