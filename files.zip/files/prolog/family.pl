parent(dipti, swara).
parent(dipti, swaraj).
parent(suyog, swara).
parent(suyog, swaraj).
parent(suhas, srinivas).
parent(pranjal, srinivas).

husband(sumant, shaila).
husband(suyog, dipti).
husband(suhas, pranjal).
husband(suresh, suman).
husband(uday, jaya).
husband(jaydeep, smita).
husband(jayant, swati).
husband(sujit, mayuri).
husband(pratik, jayanti).
husband(prasad, priyanka).
husband(rohan, gargi).


% Rules:
father(X, Y) :- male(X), parent(X, Y).
mother(X, Y) :- female(X), parent(X, Y).

son(X, Y) :- male(X), parent(Y, X).
daughter(X, Y) :- female(X), parent(Y, X).
granddaughter(X,Y) :- daughter(X,W), (son(W,Y);daughter(W,Y)).
grandson(X,Y) :- son(X,W), (son(W,Y);daughter(W,Y)).

wife(X, Y) :- husband(Y, X).

grandfather(X, Z) :- father(X, Y), parent(Y, Z).
grandmother(X, Z) :- mother(X, Y), parent(Y, Z).

sibling(X, Y) :- parent(Z, X), parent(Z, Y), X \= Y.
cousin(X, Y) :- parent(Z, X), parent(W, Y), sibling(Z, W).
niece(X, Y) :- parent(W, X), (sibling(W, Y);brother_in_law(W,Y);sister_in_law(W,Y)),female(X).
nephew(X, Y) :- parent(W, X), (sibling(W, Y);brother_in_law(W,Y);sister_in_law(W,Y)),male(X).
second_niece(X, Y) :- mother(P,X),(sister_in_law(P,Y);cousin(P,Y);cousin_in_law(P,Y)),female(X).
second_nephew(X, Y) :- mother(P,X),(sister_in_law(P,Y);cousin(P,Y);cousin_in_law(P,Y)),male(X).
cousin_nephew(X, Y) :-  parent(W,X),cousin(W,Y),male(X).
cousin_niece(X, Y) :-  parent(W,X),cousin(W,Y),female(X).


uncle(X, Y) :- parent(Z, Y), (sibling(X, Z);brother_in_law(X,Z)), male(X).
aunt(X, Y) :- (cousin(Z, Y), mother(X, Z), female(X));(sister_in_law(X,W),parent(W,Y)).
first_cousin_aunt(X, Y) :- (cousin(X,M), parent(M,Y),female(X));(husband(W,X),parent(V,Y),cousin(W,V)).
first_cousin_uncle(X, Y) :- (cousin(X,M), parent(M,Y),male(X));(wife(W,X),parent(V,Y),cousin(W,V)).
second_cousin_aunt(X, Y) :- parent(P,Y), second_cousin(P,X), female(X).


brother_in_law(X, Y) :-(husband(X, Z), sibling(Z, Y));(husband(X,W),husband(Y,V),sibling(W,V));(sibling(X,W),wife(W,Y),male(X));(husband(X,W),sister_in_law(W,Y)).
sister_in_law(X, Y) :- (sibling(X,W),(wife(W,Y);husband(W,Y)),female(X));(wife(X,M),sibling(M,V),(wife(V,Y);husband(V,Y)));(wife(X,M),sibling(M,Y)).
cousin_in_law(X, Y) :- (cousin(X, Z), (wife(Z, Y);husband(Z,Y)));((husband(X,W);wife(X,W)),cousin(W,Y));((husband(X,W);wife(X,W)),(husband(Y,V);wife(Y,V)),cousin(W,V)).
daughter_in_law(X,Y) :- wife(X,W),son(W,Y).
son_in_law(X,Y) :- husband(X,W),daughter(W,Y).
niece_in_law(X, Y) :- wife(X,M), nephew(M,Y).
nephew_in_law(X, Y) :- husband(X,M), niece(M,Y).
second_niece_in_law(X, Y) :- wife(X,M), second_nephew(M,Y).
second_nephew_in_law(X, Y) :- husband(X,M), second_niece(M,Y).


father_in_law(X, Y) :- father(X,W),(wife(W,Y);husband(W,Y)).
mother_in_law(X, Y) :- mother(X,W),(wife(W,Y);husband(W,Y)).
uncle_in_law(X, Y) :-  (husband(W,Y);wife(W,Y)),uncle(X,W).
aunt_in_law(X, Y) :- (husband(W,Y);wife(W,Y)),aunt(X,W).

grandson_in_law(X, Y) :- husband(X,W), granddaughter(W,Y).
granddaughter_in_law(X, Y) :- wife(X,M), grandson(M,Y).

grandfather_in_law(X, Y) :- grandfather(X,W), (wife(W,Y);husband(W,Y)).

grand_uncle(X, Y) :- (uncle(X, Z), parent(Z, Y));(parent(P,Y),(niece(P,X);nephew(P,X);second_niece(P,X);second_nephew(P,X)),male(X)).
grand_aunt(X, Y) :- (aunt(X, Z), parent(Z, Y));(parent(P,Y),(niece(P,X);nephew(P,X);second_niece(P,X);second_nephew(P,X)),female(X)).
grand_niece(X, Y) :- (grand_uncle(Y,X);grand_aunt(Y,X)),female(X).
grand_nephew(X, Y) :- (grand_uncle(Y,X);grand_aunt(Y,X)),male(X).


second_cousin(X, Y) :- grandfather(Z, X), grandfather(W,Y),sibling(W, Z).
paternal_cousin(X, Y) :- grandfather(Z, Y), father(W, X), sibling(Z, W).

great_grandfather(X, Z) :- father(X, Y), grandfather(Y, Z).

great_granddaughter(X, Y) :- daughter(X,M),(granddaughter(M,Y);grandson(M,Y)).
great_grandson(X, Y) :- son(X,M),(granddaughter(M,Y);grandson(M,Y)).
great_grand_niece(X, Y) :- great_granddaughter(X,P),(sibling(P,Y);brother_in_law(P,Y);sister_in_law(P,Y)),female(X).
great_great_grandfather(X, Y) :- great_grandfather(X,W),parent(W,Y).
great_great_granddaughter(X, Y) :- great_great_grandfather(Y, X).

find_relationship(X, Y) :-
    father(X, Y), write(X), write(' is the father of '), write(Y), nl.
find_relationship(X, Y) :-
    mother(X, Y), write(X), write(' is the mother of '), write(Y), nl.
find_relationship(X, Y) :-
    son(X, Y), write(X), write(' is the son of '), write(Y), nl.
find_relationship(X, Y) :-
    daughter(X, Y), write(X), write(' is the daughter of '), write(Y), nl.
find_relationship(X, Y) :-
    husband(X, Y), write(X), write(' is the husband of '), write(Y), nl.
find_relationship(X, Y) :-
    wife(X, Y), write(X), write(' is the wife of '), write(Y), nl.
find_relationship(X, Y) :-
    grandfather(X, Y), write(X), write(' is the grandfather of '), write(Y), nl.
find_relationship(X, Y) :-
    grandmother(X, Y), write(X), write(' is the grandmother of '), write(Y), nl.
find_relationship(X, Y) :-
    sibling(X, Y), write(X), write(' is the sibling of '), write(Y), nl.
find_relationship(X, Y) :-
    father(Z, Y), mother(X, Z), write(X), write(' is the grandmother of '), write(Y), nl.
find_relationship(X, Y) :-
    father_in_law(X, Y), write(X), write(' is the father-in-law of '), write(Y), nl.
find_relationship(X, Y) :-
    mother_in_law(X, Y), write(X), write(' is the mother-in-law of '), write(Y), nl.
find_relationship(X, Y) :-
    brother_in_law(X, Y), write(X), write(' is the brother-in-law of '), write(Y), nl.
find_relationship(X, Y) :-
    sister_in_law(X, Y), write(X), write(' is the sister-in-law of '), write(Y), nl.
find_relationship(X, Y) :-
    cousin_in_law(X, Y), write(X), write(' is the cousin-in-law of '), write(Y), nl.
find_relationship(X, Y) :-
    uncle_in_law(X, Y), write(X), write(' is the uncle-in-law of '), write(Y), nl.
find_relationship(X, Y) :-
    aunt_in_law(X, Y), write(X), write(' is the aunt-in-law of '), write(Y), nl.
find_relationship(X, Y) :-
    grandfather_in_law(X, Y), write(X), write(' is the grandfather-in-law of '), write(Y), nl.
find_relationship(X, Y) :-
    granddaughter_in_law(X, Y), write(X), write(' is the granddaughter-in-law of '), write(Y), nl.
find_relationship(X, Y) :-
    grandson_in_law(X, Y), write(X), write(' is the grandson-in-law of '), write(Y), nl.
find_relationship(X, Y) :-
    grand_uncle(X, Y), write(X), write(' is the grand-uncle of '), write(Y), nl.
find_relationship(X, Y) :-
    grand_aunt(X, Y), write(X), write(' is the grand-aunt of '), write(Y), nl.
find_relationship(X, Y) :-
    uncle(X, Y), write(X), write(' is the uncle of '), write(Y), nl.
find_relationship(X, Y) :-
    aunt(X, Y), write(X), write(' is the aunt of '), write(Y), nl.
find_relationship(X, Y) :-
    first_cousin_aunt(X, Y), write(X), write(' is the first cousin aunt of '), write(Y), nl.
find_relationship(X, Y) :-
    first_cousin_uncle(X, Y), write(X), write(' is the first cousin uncle of '), write(Y), nl.
find_relationship(X, Y) :-
    cousin(X, Y), write(X), write(' is the cousin of '), write(Y), nl.
find_relationship(X, Y) :-
    second_cousin(X, Y), write(X), write(' is the second cousin of '), write(Y), nl.
find_relationship(X, Y) :-
    paternal_cousin(X, Y), write(X), write(' is the paternal cousin of '), write(Y), nl.
find_relationship(X, Y) :-
    great_grandfather(X, Y), write(X), write(' is the great-grandfather of '), write(Y), nl.
find_relationship(X, Y) :-
    daughter_in_law(X, Y), write(X), write(' is the daughter in law of '), write(Y), nl.
find_relationship(X, Y) :-
    granddaughter(X, Y), write(X), write(' is the granddaughter of '), write(Y), nl.
find_relationship(X, Y) :-
    grandson(X, Y), write(X), write(' is the grandson of '), write(Y), nl.
find_relationship(X, Y) :-
    son_in_law(X, Y), write(X), write(' is the son in law of '), write(Y), nl.
find_relationship(X, Y) :-
    niece_in_law(X, Y), write(X), write(' is the niece in law of '), write(Y), nl.
find_relationship(X, Y) :-
    nephew_in_law(X, Y), write(X), write(' is the nephew in law of '), write(Y), nl.
find_relationship(X, Y) :-
   niece(X, Y), write(X), write(' is the niece of '), write(Y), nl.
find_relationship(X, Y) :-
   nephew(X, Y), write(X), write(' is the nephew of '), write(Y), nl.
find_relationship(X, Y) :-
  second_nephew(X, Y), write(X), write(' is the second nephew of '), write(Y), nl.
find_relationship(X, Y) :-
   second_niece(X, Y), write(X), write(' is the second niece of '), write(Y), nl.
find_relationship(X, Y) :-
   cousin_nephew(X, Y), write(X), write(' is the cousin nephew of '), write(Y), nl.
find_relationship(X, Y) :-
   cousin_niece(X, Y), write(X), write(' is the cousin niece of '), write(Y), nl.
find_relationship(X, Y) :-
   great_granddaughter(X, Y), write(X), write(' is the great granddaughter of '), write(Y), nl.
find_relationship(X, Y) :-
   great_grandson(X, Y), write(X), write(' is the great grandson of '), write(Y), nl.
find_relationship(X, Y) :-
   grand_niece(X, Y), write(X), write(' is the grand niece of '), write(Y), nl.
find_relationship(X, Y) :-
   grand_nephew(X, Y), write(X), write(' is the grand nephew of '), write(Y), nl.
find_relationship(X, Y) :-
great_great_granddaughter(X, Y), write(X), write(' is the great great granddaughter of '), write(Y), nl.
find_relationship(X, Y) :-
second_niece_in_law(X, Y), write(X), write(' is the second_niece_in_law of '), write(Y), nl.
find_relationship(X, Y) :-
second_nephew_in_law(X, Y), write(X), write(' is the second_nephew_in_law of '), write(Y), nl.
find_relationship(X, Y) :-
second_cousin_aunt(X, Y), write(X), write(' is the second_cousin_aunt of '), write(Y), nl.
find_relationship(X, Y) :-
great_grand_niece(X, Y), write(X), write(' is the great_grand_niece of '), write(Y), nl.

find_relationship(X, Y) :- write('Relationship not defined between '), write(X), write(' and '), write(Y), nl.