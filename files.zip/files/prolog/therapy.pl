% Knowledge Base

symptom(fatigue).
symptom(sadness).
symptom(anxiety).
symptom(insomnia).
symptom(appetite_loss).
symptom(difficulty_concentrating).
symptom(weight_changes).

has_disorder(depression) :-
    symptom(fatigue),
    symptom(sadness),
    symptom(appetite_loss).

has_disorder(anxiety) :-
    symptom(anxiety),
    symptom(insomnia),
    symptom(difficulty_concentrating).

has_disorder(eating_disorder) :-
    symptom(weight_changes),
    symptom(appetite_loss).

advice(depression, 'It\'s crucial to seek professional help for depression. Reach out to a mental health expert for a proper evaluation and guidance.').

advice(anxiety, 'If you have symptoms of anxiety, consider relaxation techniques and consult a mental health professional for further support.').

advice(eating_disorder, 'If you suspect an eating disorder, it\'s important to talk to a healthcare professional. They can provide guidance on developing a healthy relationship with food and body image.').

% Inference Engine

assess_mental_health(Disorder) :-
    has_disorder(Disorder),
    write('Based on your symptoms, you may be experiencing symptoms of '), write(Disorder), write('.').

provide_advice(Disorder) :-
    advice(Disorder, Advice),
    write(Advice).

% User Interaction

start :-
    write('Welcome to the Mental Health Expert System. Please answer the following questions to assess your mental health.'), nl,
    ask_symptoms.

ask_symptoms :-
    write('Do you experience fatigue? (yes/no)'), read(Response1),
    write('Do you feel sadness? (yes/no)'), read(Response2),
    write('Do you have anxiety? (yes/no)'), read(Response3),
    write('Do you have trouble sleeping? (yes/no)'), read(Response4),
    write('Do you experience appetite loss? (yes/no)'), read(Response5),
    write('Do you have difficulty concentrating? (yes/no)'), read(Response6),
    write('Have you noticed significant weight changes? (yes/no)'), read(Response7),
    process_responses(Response1, Response2, Response3, Response4, Response5, Response6, Response7).

process_responses(yes, yes, _, _, _, _, _) :- provide_advice(depression).
process_responses(_, _, yes, yes, yes, _, _) :- provide_advice(anxiety).
process_responses(_, _, _, _, _, _, yes) :- provide_advice(eating_disorder).
process_responses(_, _, _, _, _, _, _) :- write('You may not be experiencing a known mental health disorder. It\'s advisable to consult a professional for a more accurate assessment.').

% Example usage
% Call the start predicate to initiate the interaction.
% You can customize this with more symptoms, disorders, and refine the interaction.

% start.